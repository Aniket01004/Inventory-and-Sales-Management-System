import { useState } from "react";
import api from "../api/axios";

function CreateSale() {
  const [productId, setProductId] = useState("");
  const [quantity, setQuantity] = useState("");

  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSale = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      await api.post(
        `/products/${productId}/sale?quantity=${quantity}`
      );

      setMessage("Sale created successfully");
      setProductId("");
      setQuantity("");

    } catch (error) {
      setMessage("Failed to create sale");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-lg bg-white shadow rounded p-6">
      <h2 className="text-xl font-semibold mb-6">
        Create Sale
      </h2>

      {message && (
        <p className="mb-4 text-sm text-red-500">{message}</p>
      )}

      <form onSubmit={handleSale} className="space-y-4">

        <div>
          <label className="block text-sm font-medium mb-1">
            Product ID
          </label>
          <input
            type="number"
            value={productId}
            required
            onChange={(e) => setProductId(e.target.value)}
            className="w-full border rounded px-3 py-2"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">
            Quantity
          </label>
          <input
            type="number"
            value={quantity}
            required
            onChange={(e) => setQuantity(e.target.value)}
            className="w-full border rounded px-3 py-2"
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded"
        >
          {loading ? "Processing..." : "Create Sale"}
        </button>

      </form>
    </div>
  );
}

export default CreateSale;
