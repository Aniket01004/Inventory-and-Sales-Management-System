import { useEffect, useState } from "react";
import api from "../api/axios";

function MonthlyReport() {
  const [total, setTotal] = useState(0);

  useEffect(() => {
    api.get("/dashboard/summary")
      .then(res => setTotal(res.data.monthlySales))
      .catch(() => alert("Error loading report"));
  }, []);

  return (
    <div className="bg-white p-6 rounded shadow">
      <h2 className="text-xl font-bold">Monthly Sales</h2>
      <p className="text-3xl mt-4">₹{total}</p>
    </div>
  );
}

export default MonthlyReport;
