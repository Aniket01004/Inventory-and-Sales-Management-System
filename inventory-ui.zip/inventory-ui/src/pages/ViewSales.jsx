import { useEffect, useState } from "react";
import api from "../api/axios";

function ViewSales() {
  const [sales, setSales] = useState([]);

  useEffect(() => {
    api.get("/sales")
      .then(res => setSales(res.data))
      .catch(() => alert("Error loading sales"));
  }, []);

  return (
    <div className="bg-white p-6 rounded shadow">
      <h2 className="text-xl font-bold mb-4">Sales List</h2>

      <table className="w-full border">
        <thead>
          <tr className="border-b">
            <th>ID</th>
            <th>Product</th>
            <th>Quantity</th>
            <th>Total</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          {sales.map(sale => (
            <tr key={sale.id} className="border-b">
              <td>{sale.id}</td>
              <td>{sale.product.name}</td>
              <td>{sale.quantity}</td>
              <td>₹{sale.totalPrice}</td>
              <td>{sale.saleDate}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ViewSales;
