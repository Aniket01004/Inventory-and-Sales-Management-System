import React, { useEffect, useState } from "react";
import api from "../api/axios";   // ✅ use centralized axios

function Dashboard() {

  const [summary, setSummary] = useState(null);
  const [lowStock, setLowStock] = useState([]);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {

      // ✅ No manual headers
      const summaryRes = await api.get("/dashboard/summary");

      const lowStockRes = await api.get(
        "/products/low-stock?threshold=5"
      );

      setSummary(summaryRes.data);
      setLowStock(lowStockRes.data);

    } catch (error) {
      console.error("Dashboard error:", error);
    }
  };

  if (!summary) return <p>Loading dashboard...</p>;

  return (
    <div className="space-y-8">

      <h2 className="text-2xl font-bold">Dashboard</h2>

      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-6">
        <div className="bg-white shadow rounded p-5">
          <h3 className="text-gray-500">Low Stock Count</h3>
          <p className="text-2xl font-bold">{summary.lowStockCount}</p>
        </div>

        <div className="bg-white shadow rounded p-5">
          <h3 className="text-gray-500">Today's Sales</h3>
          <p className="text-2xl font-bold">₹ {summary.todaySales}</p>
        </div>

        <div className="bg-white shadow rounded p-5">
          <h3 className="text-gray-500">Monthly Sales</h3>
          <p className="text-2xl font-bold">₹ {summary.monthlySales}</p>
        </div>
      </div>

      {/* Low Stock Table */}
      <div className="bg-white shadow rounded p-5">
        <h3 className="text-lg font-semibold mb-4">
          Low Stock Products
        </h3>

        <table className="w-full text-left">
          <thead>
            <tr className="border-b">
              <th className="py-2">Name</th>
              <th className="py-2">Quantity</th>
            </tr>
          </thead>
          <tbody>
            {lowStock.map(product => (
              <tr key={product.id} className="border-b">
                <td className="py-2">{product.name}</td>
                <td className="py-2 text-red-500 font-semibold">
                  {product.quantity}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {lowStock.length === 0 && (
          <p className="text-gray-500 mt-3">
            No low stock products.
          </p>
        )}

      </div>
    </div>
  );
}

export default Dashboard;