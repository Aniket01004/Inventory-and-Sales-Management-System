import React, { useEffect, useState } from 'react'
import api from '../api/axios';

function ProductList() {
  const[products,setProducts] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    api.get("/products")
    .then((response) => {
      setProducts(response.data);
    })
    .catch(() => {
      setError("Failed to load products");
    });
  
  }, [])
  


  return (
  <div className="bg-white p-6 rounded shadow">
    <h2 className="text-xl font-bold mb-4">Product List</h2>

    {error && <p className="text-red-500">{error}</p>}

    {products.length === 0 ? (
      <p>No products available</p>
    ) : (
      <table className="min-w-full">
        <thead>
          <tr className="bg-gray-100 text-left">
            <th className="p-3">Name</th>
            <th className="p-3">Price</th>
            <th className="p-3">Quantity</th>
            <th className="p-3">Image</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => (
            <tr key={product.id} className="hover:bg-gray-50">
              <td className="p-3 border-b">{product.name}</td>
              <td className="p-3 border-b">₹{product.price}</td>
              <td className="p-3 border-b">{product.quantity}</td>
              <td className="p-3 border-b">
                {product.imageUrl ? (
                  <img
                    src={`http://localhost:8080/uploads/${product.imageUrl}`}
                    className="w-16 h-16 object-cover rounded"
                    alt={product.name}
                  />
                ) : (
                  <span className="text-gray-400 text-sm">
                    No Image
                  </span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    )}
  </div>
);

}

export default ProductList