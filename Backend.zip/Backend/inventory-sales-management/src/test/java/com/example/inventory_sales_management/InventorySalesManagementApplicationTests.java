package com.example.inventory_sales_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventorySalesManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
