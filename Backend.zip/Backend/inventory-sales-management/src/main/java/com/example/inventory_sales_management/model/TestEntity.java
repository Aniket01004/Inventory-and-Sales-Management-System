package com.example.inventory_sales_management.model;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

public class TestEntity {
    @Id
    @GeneratedValue
    private Long id;
}
