package com.example.inventory_sales_management.model;

public enum TransactionType {
    IN,
    OUT
}
